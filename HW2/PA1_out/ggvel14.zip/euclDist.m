function D = euclDist( X, Y)

    D=sqrt(sum( (X - Y).^2 ));

end